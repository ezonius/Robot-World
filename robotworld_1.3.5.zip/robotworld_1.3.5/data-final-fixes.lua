require("prototypes.technologies")
require("prototypes.entities")
require("prototypes.recipes")
require("prototypes.items")
data.raw["item"]["logistic-robot"].stack_size = settings.startup["robot-stack-size"].value
data.raw["item"]["construction-robot"].stack_size = settings.startup["robot-stack-size"].value